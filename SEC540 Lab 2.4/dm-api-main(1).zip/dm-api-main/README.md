# SEC540 - DM API

Provides the backend API & data store for the DM applications.
